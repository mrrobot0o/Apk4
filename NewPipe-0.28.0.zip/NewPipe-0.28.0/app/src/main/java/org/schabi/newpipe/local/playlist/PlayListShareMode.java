package org.schabi.newpipe.local.playlist;

public enum PlayListShareMode {

    JUST_URLS,
    WITH_TITLES,
    YOUTUBE_TEMP_PLAYLIST
}
