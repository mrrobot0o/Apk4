package org.schabi.newpipe.util;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class FallbackViewHolder extends RecyclerView.ViewHolder {
    public FallbackViewHolder(final View itemView) {
        super(itemView);
    }
}
