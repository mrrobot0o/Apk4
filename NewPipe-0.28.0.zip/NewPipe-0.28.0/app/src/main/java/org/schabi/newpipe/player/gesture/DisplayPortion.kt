package org.schabi.newpipe.player.gesture

enum class DisplayPortion {
    LEFT, MIDDLE, RIGHT, LEFT_HALF, RIGHT_HALF
}
