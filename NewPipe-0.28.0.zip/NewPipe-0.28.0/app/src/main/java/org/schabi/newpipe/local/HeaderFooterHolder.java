package org.schabi.newpipe.local;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class HeaderFooterHolder extends RecyclerView.ViewHolder {
    public View view;

    public HeaderFooterHolder(final View v) {
        super(v);
        view = v;
    }
}
