package com.bda.streaming.features.performance

import android.content.Context
import android.os.Build
import android.os.PowerManager
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Bda Performance Optimizer
 * Features:
 * - Smart caching with automatic cleanup
 * - Battery-aware playback quality
 * - Network-aware content loading
 * - Memory optimization
 */
class PerformanceOptimizer(private val context: Context) {

    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val cacheDir = File(context.cacheDir, "bda_cache")

    companion object {
        private const val MAX_CACHE_SIZE_MB = 500L
        private const val CACHE_CLEANUP_THRESHOLD_MB = 400L
        private const val MAX_CACHE_AGE_DAYS = 7L
    }

    init {
        if (!cacheDir.exists()) {
            cacheDir.mkdirs()
        }
    }

    /**
     * Check if device is in battery saver mode
     */
    fun isBatterySaverActive(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            powerManager.isPowerSaveMode
        } else {
            false
        }
    }

    /**
     * Get recommended video quality based on battery and network
     */
    fun getRecommendedQuality(): VideoQuality {
        return when {
            isBatterySaverActive() -> VideoQuality.MEDIUM
            isLowBattery() -> VideoQuality.MEDIUM
            isOnMobileData() -> VideoQuality.MEDIUM
            else -> VideoQuality.HIGH
        }
    }

    /**
     * Check if battery is low
     */
    private fun isLowBattery(): Boolean {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
        val batteryLevel = batteryManager?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
        return batteryLevel < 20
    }

    /**
     * Check if device is on mobile data
     */
    private fun isOnMobileData(): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) 
            as? android.net.ConnectivityManager
        val activeNetwork = connectivityManager?.activeNetworkInfo
        return activeNetwork?.type == android.net.ConnectivityManager.TYPE_MOBILE
    }

    /**
     * Get current cache size in MB
     */
    fun getCacheSizeMB(): Long {
        return getFolderSize(cacheDir) / (1024 * 1024)
    }

    /**
     * Clean up old cache files
     */
    fun cleanupCache() {
        val currentSize = getCacheSizeMB()
        
        if (currentSize > CACHE_CLEANUP_THRESHOLD_MB) {
            // Delete files older than MAX_CACHE_AGE_DAYS
            val cutoffTime = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(MAX_CACHE_AGE_DAYS)
            
            cacheDir.listFiles()?.forEach { file ->
                if (file.lastModified() < cutoffTime) {
                    file.deleteRecursively()
                }
            }
        }
        
        // If still over limit, delete oldest files
        if (getCacheSizeMB() > MAX_CACHE_SIZE_MB) {
            val files = cacheDir.listFiles()?.sortedBy { it.lastModified() } ?: emptyList()
            var deletedSize = 0L
            
            for (file in files) {
                if (getCacheSizeMB() <= CACHE_CLEANUP_THRESHOLD_MB) break
                deletedSize += getFolderSize(file)
                file.deleteRecursively()
            }
        }
    }

    /**
     * Get folder size in bytes
     */
    private fun getFolderSize(folder: File): Long {
        var size = 0L
        folder.listFiles()?.forEach { file ->
            size += if (file.isDirectory) {
                getFolderSize(file)
            } else {
                file.length()
            }
        }
        return size
    }

    /**
     * Clear all cache
     */
    fun clearAllCache() {
        cacheDir.deleteRecursively()
        cacheDir.mkdirs()
    }

    /**
     * Optimize memory usage
     */
    fun optimizeMemory() {
        System.gc()
        cleanupCache()
    }

    /**
     * Get cache statistics
     */
    fun getCacheStats(): CacheStats {
        val files = cacheDir.listFiles() ?: emptyArray()
        return CacheStats(
            totalSizeMB = getCacheSizeMB(),
            fileCount = files.size,
            oldestFileAge = files.minOfOrNull { 
                System.currentTimeMillis() - it.lastModified() 
            } ?: 0L
        )
    }

    data class CacheStats(
        val totalSizeMB: Long,
        val fileCount: Int,
        val oldestFileAge: Long
    )

    enum class VideoQuality {
        LOW,      // 360p or lower
        MEDIUM,   // 480p - 720p
        HIGH,     // 1080p
        ULTRA     // 1440p and above
    }
}

