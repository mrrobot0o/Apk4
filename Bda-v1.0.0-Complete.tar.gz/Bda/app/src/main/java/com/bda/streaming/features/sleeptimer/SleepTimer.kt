package com.bda.streaming.features.sleeptimer

import android.os.CountDownTimer
import io.reactivex.rxjava3.subjects.BehaviorSubject

/**
 * Bda Sleep Timer - Automatically pause playback after a specified duration
 * Features:
 * - Customizable duration (15, 30, 45, 60, 90, 120 minutes)
 * - Gradual volume fade-out in the last minute
 * - Observable state for UI updates
 */
class SleepTimer(
    private val onTimerFinished: () -> Unit,
    private val onVolumeChange: (Float) -> Unit
) {

    private var timer: CountDownTimer? = null
    private var fadeOutTimer: CountDownTimer? = null
    
    val timeRemaining = BehaviorSubject.createDefault(0L)
    val isActive = BehaviorSubject.createDefault(false)

    companion object {
        const val FADE_OUT_DURATION = 60000L // 1 minute in milliseconds
        val PRESET_DURATIONS = listOf(
            15 * 60 * 1000L,  // 15 minutes
            30 * 60 * 1000L,  // 30 minutes
            45 * 60 * 1000L,  // 45 minutes
            60 * 60 * 1000L,  // 60 minutes
            90 * 60 * 1000L,  // 90 minutes
            120 * 60 * 1000L  // 120 minutes
        )
    }

    /**
     * Start the sleep timer with the specified duration
     * @param durationMillis Duration in milliseconds
     */
    fun start(durationMillis: Long) {
        cancel()

        timer = object : CountDownTimer(durationMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeRemaining.onNext(millisUntilFinished)
                
                // Start fade-out in the last minute
                if (millisUntilFinished <= FADE_OUT_DURATION && fadeOutTimer == null) {
                    startFadeOut()
                }
            }

            override fun onFinish() {
                timeRemaining.onNext(0L)
                isActive.onNext(false)
                onTimerFinished()
            }
        }.start()

        isActive.onNext(true)
    }

    /**
     * Start gradual volume fade-out
     */
    private fun startFadeOut() {
        fadeOutTimer = object : CountDownTimer(FADE_OUT_DURATION, 100) {
            override fun onTick(millisUntilFinished: Long) {
                val volumeLevel = millisUntilFinished.toFloat() / FADE_OUT_DURATION
                onVolumeChange(volumeLevel)
            }

            override fun onFinish() {
                onVolumeChange(0f)
            }
        }.start()
    }

    /**
     * Cancel the sleep timer
     */
    fun cancel() {
        timer?.cancel()
        timer = null
        fadeOutTimer?.cancel()
        fadeOutTimer = null
        timeRemaining.onNext(0L)
        isActive.onNext(false)
        onVolumeChange(1f) // Restore full volume
    }

    /**
     * Add time to the current timer
     * @param additionalMillis Additional time in milliseconds
     */
    fun addTime(additionalMillis: Long) {
        val currentTime = timeRemaining.value ?: 0L
        if (currentTime > 0) {
            start(currentTime + additionalMillis)
        }
    }

    /**
     * Get formatted time remaining string
     */
    fun getFormattedTimeRemaining(): String {
        val millis = timeRemaining.value ?: 0L
        val minutes = (millis / 1000 / 60).toInt()
        val seconds = ((millis / 1000) % 60).toInt()
        return String.format("%02d:%02d", minutes, seconds)
    }
}

