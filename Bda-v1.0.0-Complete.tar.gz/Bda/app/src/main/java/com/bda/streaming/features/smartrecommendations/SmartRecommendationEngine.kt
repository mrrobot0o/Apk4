package com.bda.streaming.features.smartrecommendations

import android.content.Context
import android.content.SharedPreferences
import io.reactivex.rxjava3.core.Single
import io.reactivex.rxjava3.schedulers.Schedulers
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Bda Smart Recommendation Engine
 * AI-powered content recommendations based on:
 * - Watch history
 * - Watch time patterns
 * - Content preferences
 * - Trending content
 */
class SmartRecommendationEngine(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        "bda_smart_recommendations", Context.MODE_PRIVATE
    )

    data class WatchHistoryItem(
        val videoId: String,
        val title: String,
        val category: String,
        val watchDuration: Long,
        val totalDuration: Long,
        val timestamp: Long
    )

    data class RecommendationScore(
        val videoId: String,
        val score: Double,
        val reason: String
    )

    /**
     * Track a video watch event
     */
    fun trackWatch(item: WatchHistoryItem) {
        val history = getWatchHistory().toMutableList()
        history.add(0, item)
        
        // Keep only last 100 items
        if (history.size > 100) {
            history.subList(100, history.size).clear()
        }
        
        saveWatchHistory(history)
        updatePreferences(item)
    }

    /**
     * Get personalized recommendations
     */
    fun getRecommendations(candidateVideos: List<String>): Single<List<RecommendationScore>> {
        return Single.fromCallable {
            val history = getWatchHistory()
            val preferences = getUserPreferences()
            
            candidateVideos.map { videoId ->
                val score = calculateRecommendationScore(videoId, history, preferences)
                RecommendationScore(videoId, score, getRecommendationReason(score))
            }.sortedByDescending { it.score }
        }.subscribeOn(Schedulers.computation())
    }

    /**
     * Calculate recommendation score for a video
     */
    private fun calculateRecommendationScore(
        videoId: String,
        history: List<WatchHistoryItem>,
        preferences: Map<String, Float>
    ): Double {
        var score = 0.0

        // Check if already watched
        val alreadyWatched = history.any { it.videoId == videoId }
        if (alreadyWatched) {
            score -= 50.0
        }

        // Category preference scoring
        val categoryScore = preferences["category_preference"] ?: 0f
        score += categoryScore * 20

        // Time-based scoring (prefer content matching user's active hours)
        val currentHour = System.currentTimeMillis() / (1000 * 60 * 60) % 24
        val userActiveHours = preferences["active_hour_$currentHour"] ?: 0f
        score += userActiveHours * 10

        // Completion rate influence
        val avgCompletionRate = history
            .filter { it.totalDuration > 0 }
            .map { it.watchDuration.toDouble() / it.totalDuration }
            .average()
        
        if (!avgCompletionRate.isNaN()) {
            score += avgCompletionRate * 15
        }

        // Recency boost
        val recentWatches = history.take(10)
        if (recentWatches.isNotEmpty()) {
            score += 5.0
        }

        return score.coerceIn(0.0, 100.0)
    }

    /**
     * Get recommendation reason based on score
     */
    private fun getRecommendationReason(score: Double): String {
        return when {
            score > 80 -> "Highly recommended for you"
            score > 60 -> "Based on your interests"
            score > 40 -> "You might like this"
            score > 20 -> "Trending now"
            else -> "Discover something new"
        }
    }

    /**
     * Update user preferences based on watch behavior
     */
    private fun updatePreferences(item: WatchHistoryItem) {
        val editor = prefs.edit()
        
        // Update category preference
        val categoryKey = "category_${item.category}"
        val currentPref = prefs.getFloat(categoryKey, 0f)
        editor.putFloat(categoryKey, (currentPref + 0.1f).coerceAtMost(1f))
        
        // Update active hour preference
        val hour = (item.timestamp / (1000 * 60 * 60)) % 24
        val hourKey = "active_hour_$hour"
        val currentHourPref = prefs.getFloat(hourKey, 0f)
        editor.putFloat(hourKey, (currentHourPref + 0.05f).coerceAtMost(1f))
        
        editor.apply()
    }

    /**
     * Get user preferences
     */
    private fun getUserPreferences(): Map<String, Float> {
        return prefs.all.mapNotNull { (key, value) ->
            if (value is Float) key to value else null
        }.toMap()
    }

    /**
     * Get watch history
     */
    private fun getWatchHistory(): List<WatchHistoryItem> {
        val historyJson = prefs.getString("watch_history", "[]") ?: "[]"
        val jsonArray = JSONArray(historyJson)
        val history = mutableListOf<WatchHistoryItem>()
        
        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)
            history.add(
                WatchHistoryItem(
                    videoId = obj.getString("videoId"),
                    title = obj.getString("title"),
                    category = obj.getString("category"),
                    watchDuration = obj.getLong("watchDuration"),
                    totalDuration = obj.getLong("totalDuration"),
                    timestamp = obj.getLong("timestamp")
                )
            )
        }
        
        return history
    }

    /**
     * Save watch history
     */
    private fun saveWatchHistory(history: List<WatchHistoryItem>) {
        val jsonArray = JSONArray()
        history.forEach { item ->
            val obj = JSONObject().apply {
                put("videoId", item.videoId)
                put("title", item.title)
                put("category", item.category)
                put("watchDuration", item.watchDuration)
                put("totalDuration", item.totalDuration)
                put("timestamp", item.timestamp)
            }
            jsonArray.put(obj)
        }
        
        prefs.edit().putString("watch_history", jsonArray.toString()).apply()
    }

    /**
     * Clear all recommendations data
     */
    fun clearData() {
        prefs.edit().clear().apply()
    }
}

