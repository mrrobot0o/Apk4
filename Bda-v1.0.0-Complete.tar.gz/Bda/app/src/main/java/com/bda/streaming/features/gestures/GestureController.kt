package com.bda.streaming.features.gestures

import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/**
 * Bda Gesture Controller - Smart gesture controls for video playback
 * Supports:
 * - Vertical swipe on left side: Brightness control
 * - Vertical swipe on right side: Volume control
 * - Horizontal swipe: Seek forward/backward
 * - Double tap left/right: Skip 10 seconds
 */
class GestureController(
    context: Context,
    private val listener: GestureListener
) : View.OnTouchListener {

    private val gestureDetector: GestureDetector
    private var initialX = 0f
    private var initialY = 0f
    private var isVolumeGesture = false
    private var isBrightnessGesture = false
    private var isSeekGesture = false

    interface GestureListener {
        fun onVolumeChange(delta: Float)
        fun onBrightnessChange(delta: Float)
        fun onSeek(delta: Long)
        fun onDoubleTapLeft()
        fun onDoubleTapRight()
    }

    init {
        gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val screenWidth = (e.view?.width ?: 0).toFloat()
                if (e.x < screenWidth / 2) {
                    listener.onDoubleTapLeft()
                } else {
                    listener.onDoubleTapRight()
                }
                return true
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                if (e1 == null) return false

                val deltaX = e2.x - e1.x
                val deltaY = e2.y - e1.y
                val screenWidth = (e2.view?.width ?: 0).toFloat()

                // Determine gesture type based on initial touch position and movement
                if (!isVolumeGesture && !isBrightnessGesture && !isSeekGesture) {
                    if (abs(deltaY) > abs(deltaX)) {
                        // Vertical gesture
                        if (e1.x > screenWidth / 2) {
                            isVolumeGesture = true
                        } else {
                            isBrightnessGesture = true
                        }
                    } else {
                        // Horizontal gesture
                        isSeekGesture = true
                    }
                }

                when {
                    isVolumeGesture -> {
                        listener.onVolumeChange(-deltaY / 500f)
                    }
                    isBrightnessGesture -> {
                        listener.onBrightnessChange(-deltaY / 500f)
                    }
                    isSeekGesture -> {
                        val seekDelta = (deltaX * 100).toLong()
                        listener.onSeek(seekDelta)
                    }
                }

                return true
            }
        })
    }

    override fun onTouch(v: View?, event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = event.x
                initialY = event.y
                isVolumeGesture = false
                isBrightnessGesture = false
                isSeekGesture = false
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isVolumeGesture = false
                isBrightnessGesture = false
                isSeekGesture = false
            }
        }
        return gestureDetector.onTouchEvent(event)
    }
}

