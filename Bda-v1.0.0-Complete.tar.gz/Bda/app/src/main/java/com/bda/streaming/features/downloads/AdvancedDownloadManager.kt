package com.bda.streaming.features.downloads

import android.content.Context
import io.reactivex.rxjava3.core.Observable
import io.reactivex.rxjava3.subjects.BehaviorSubject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.PriorityBlockingQueue

/**
 * Bda Advanced Download Manager
 * Features:
 * - Priority-based download queue
 * - Parallel downloads with configurable limit
 * - Auto-retry on failure
 * - Network-aware downloading
 * - Download scheduling
 */
class AdvancedDownloadManager(private val context: Context) {

    private val downloadQueue = PriorityBlockingQueue<DownloadTask>()
    private val activeDownloads = ConcurrentHashMap<String, DownloadTask>()
    private val downloadProgress = BehaviorSubject.createDefault<Map<String, DownloadProgress>>(emptyMap())
    
    private var maxParallelDownloads = 3
    private var isWifiOnly = false
    private var autoRetryEnabled = true
    private var maxRetries = 3

    data class DownloadTask(
        val id: String,
        val url: String,
        val title: String,
        val priority: Priority,
        val quality: String,
        val fileSize: Long = 0L,
        var retryCount: Int = 0
    ) : Comparable<DownloadTask> {
        override fun compareTo(other: DownloadTask): Int {
            return other.priority.ordinal - this.priority.ordinal
        }
    }

    enum class Priority {
        HIGH,
        NORMAL,
        LOW
    }

    data class DownloadProgress(
        val id: String,
        val title: String,
        val bytesDownloaded: Long,
        val totalBytes: Long,
        val status: DownloadStatus,
        val speed: Long, // bytes per second
        val estimatedTimeRemaining: Long // seconds
    ) {
        val progressPercentage: Int
            get() = if (totalBytes > 0) {
                ((bytesDownloaded * 100) / totalBytes).toInt()
            } else 0
    }

    enum class DownloadStatus {
        QUEUED,
        DOWNLOADING,
        PAUSED,
        COMPLETED,
        FAILED,
        CANCELLED
    }

    /**
     * Add a download to the queue
     */
    fun addDownload(task: DownloadTask) {
        downloadQueue.offer(task)
        updateProgress(task.id, DownloadProgress(
            id = task.id,
            title = task.title,
            bytesDownloaded = 0L,
            totalBytes = task.fileSize,
            status = DownloadStatus.QUEUED,
            speed = 0L,
            estimatedTimeRemaining = 0L
        ))
        processQueue()
    }

    /**
     * Process the download queue
     */
    private fun processQueue() {
        while (activeDownloads.size < maxParallelDownloads && downloadQueue.isNotEmpty()) {
            val task = downloadQueue.poll() ?: break
            startDownload(task)
        }
    }

    /**
     * Start downloading a task
     */
    private fun startDownload(task: DownloadTask) {
        if (!shouldDownload()) {
            // Re-queue if conditions aren't met
            downloadQueue.offer(task)
            return
        }

        activeDownloads[task.id] = task
        updateProgress(task.id, DownloadProgress(
            id = task.id,
            title = task.title,
            bytesDownloaded = 0L,
            totalBytes = task.fileSize,
            status = DownloadStatus.DOWNLOADING,
            speed = 0L,
            estimatedTimeRemaining = 0L
        ))

        // Actual download implementation would go here
        // This is a placeholder for the download logic
    }

    /**
     * Check if downloads should proceed based on network conditions
     */
    private fun shouldDownload(): Boolean {
        if (isWifiOnly) {
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) 
                as? android.net.ConnectivityManager
            val activeNetwork = connectivityManager?.activeNetworkInfo
            return activeNetwork?.type == android.net.ConnectivityManager.TYPE_WIFI
        }
        return true
    }

    /**
     * Pause a download
     */
    fun pauseDownload(downloadId: String) {
        activeDownloads[downloadId]?.let { task ->
            activeDownloads.remove(downloadId)
            downloadQueue.offer(task)
            updateProgressStatus(downloadId, DownloadStatus.PAUSED)
        }
    }

    /**
     * Resume a download
     */
    fun resumeDownload(downloadId: String) {
        processQueue()
    }

    /**
     * Cancel a download
     */
    fun cancelDownload(downloadId: String) {
        activeDownloads.remove(downloadId)
        updateProgressStatus(downloadId, DownloadStatus.CANCELLED)
        processQueue()
    }

    /**
     * Retry a failed download
     */
    fun retryDownload(downloadId: String) {
        // Find the task and re-add to queue
        processQueue()
    }

    /**
     * Set maximum parallel downloads
     */
    fun setMaxParallelDownloads(max: Int) {
        maxParallelDownloads = max.coerceIn(1, 5)
        processQueue()
    }

    /**
     * Enable/disable WiFi-only downloads
     */
    fun setWifiOnly(enabled: Boolean) {
        isWifiOnly = enabled
    }

    /**
     * Get observable download progress
     */
    fun observeProgress(): Observable<Map<String, DownloadProgress>> {
        return downloadProgress
    }

    /**
     * Update download progress
     */
    private fun updateProgress(id: String, progress: DownloadProgress) {
        val currentProgress = downloadProgress.value?.toMutableMap() ?: mutableMapOf()
        currentProgress[id] = progress
        downloadProgress.onNext(currentProgress)
    }

    /**
     * Update download status
     */
    private fun updateProgressStatus(id: String, status: DownloadStatus) {
        val currentProgress = downloadProgress.value?.get(id)
        currentProgress?.let {
            updateProgress(id, it.copy(status = status))
        }
    }

    /**
     * Get all downloads
     */
    fun getAllDownloads(): List<DownloadProgress> {
        return downloadProgress.value?.values?.toList() ?: emptyList()
    }

    /**
     * Get active downloads count
     */
    fun getActiveDownloadsCount(): Int {
        return activeDownloads.size
    }

    /**
     * Get queued downloads count
     */
    fun getQueuedDownloadsCount(): Int {
        return downloadQueue.size
    }

    /**
     * Clear completed downloads
     */
    fun clearCompleted() {
        val currentProgress = downloadProgress.value?.toMutableMap() ?: mutableMapOf()
        currentProgress.entries.removeIf { it.value.status == DownloadStatus.COMPLETED }
        downloadProgress.onNext(currentProgress)
    }
}

