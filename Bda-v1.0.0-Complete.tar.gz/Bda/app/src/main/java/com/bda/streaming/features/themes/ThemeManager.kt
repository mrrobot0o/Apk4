package com.bda.streaming.features.themes

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate

/**
 * Bda Theme Manager - Material Design 3 dynamic theming
 * Features:
 * - Light/Dark/Auto modes
 * - Custom accent colors
 * - AMOLED black theme
 * - Dynamic color support (Android 12+)
 */
class ThemeManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        "bda_theme_prefs", Context.MODE_PRIVATE
    )

    enum class ThemeMode {
        LIGHT,
        DARK,
        AUTO,
        AMOLED_BLACK
    }

    enum class AccentColor(val colorResId: Int) {
        BLUE(0xFF2196F3.toInt()),
        RED(0xFFF44336.toInt()),
        GREEN(0xFF4CAF50.toInt()),
        PURPLE(0xFF9C27B0.toInt()),
        ORANGE(0xFFFF9800.toInt()),
        TEAL(0xFF009688.toInt()),
        PINK(0xFFE91E63.toInt()),
        INDIGO(0xFF3F51B5.toInt())
    }

    companion object {
        private const val KEY_THEME_MODE = "theme_mode"
        private const val KEY_ACCENT_COLOR = "accent_color"
        private const val KEY_DYNAMIC_COLORS = "dynamic_colors"
        private const val KEY_AMOLED_BLACK = "amoled_black"
    }

    /**
     * Get current theme mode
     */
    fun getThemeMode(): ThemeMode {
        val mode = prefs.getString(KEY_THEME_MODE, ThemeMode.AUTO.name)
        return ThemeMode.valueOf(mode ?: ThemeMode.AUTO.name)
    }

    /**
     * Set theme mode
     */
    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
        applyTheme()
    }

    /**
     * Get current accent color
     */
    fun getAccentColor(): AccentColor {
        val color = prefs.getString(KEY_ACCENT_COLOR, AccentColor.BLUE.name)
        return AccentColor.valueOf(color ?: AccentColor.BLUE.name)
    }

    /**
     * Set accent color
     */
    fun setAccentColor(color: AccentColor) {
        prefs.edit().putString(KEY_ACCENT_COLOR, color.name).apply()
    }

    /**
     * Check if dynamic colors are enabled
     */
    fun isDynamicColorsEnabled(): Boolean {
        return prefs.getBoolean(KEY_DYNAMIC_COLORS, true)
    }

    /**
     * Enable/disable dynamic colors
     */
    fun setDynamicColorsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_DYNAMIC_COLORS, enabled).apply()
    }

    /**
     * Check if AMOLED black theme is enabled
     */
    fun isAmoledBlackEnabled(): Boolean {
        return prefs.getBoolean(KEY_AMOLED_BLACK, false)
    }

    /**
     * Enable/disable AMOLED black theme
     */
    fun setAmoledBlackEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AMOLED_BLACK, enabled).apply()
        applyTheme()
    }

    /**
     * Apply the current theme
     */
    fun applyTheme() {
        val mode = getThemeMode()
        val nightMode = when (mode) {
            ThemeMode.LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
            ThemeMode.DARK, ThemeMode.AMOLED_BLACK -> AppCompatDelegate.MODE_NIGHT_YES
            ThemeMode.AUTO -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(nightMode)
    }

    /**
     * Get theme resource ID based on current settings
     */
    fun getThemeResourceId(): Int {
        // This would return the appropriate theme resource ID
        // For now, returning a placeholder
        return when {
            isAmoledBlackEnabled() -> android.R.style.Theme_DeviceDefault // Placeholder
            getThemeMode() == ThemeMode.DARK -> android.R.style.Theme_Material
            else -> android.R.style.Theme_Material_Light
        }
    }

    /**
     * Check if dark mode is currently active
     */
    fun isDarkModeActive(context: Context): Boolean {
        val mode = getThemeMode()
        return when (mode) {
            ThemeMode.DARK, ThemeMode.AMOLED_BLACK -> true
            ThemeMode.LIGHT -> false
            ThemeMode.AUTO -> {
                val uiMode = context.resources.configuration.uiMode and 
                    android.content.res.Configuration.UI_MODE_NIGHT_MASK
                uiMode == android.content.res.Configuration.UI_MODE_NIGHT_YES
            }
        }
    }
}

