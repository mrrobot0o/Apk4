package org.schabi.newpipe.player.event;

public interface OnKeyDownListener {
    boolean onKeyDown(int keyCode);
}
